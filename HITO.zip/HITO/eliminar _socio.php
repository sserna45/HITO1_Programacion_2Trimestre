<?php
require_once "socioscontroller.php";

$controlador = new SociosController();

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $controlador->eliminarSocio($id);
    header("Location: lista_socio.php");
    exit();
} else {
    echo "Error: ID de socio no especificado.";
}
?>



