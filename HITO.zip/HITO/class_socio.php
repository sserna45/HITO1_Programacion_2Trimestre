<?php
class Socio {
    public $id;
    public $nombre;
    public $email;
    public $edad;
    public $plan_base;
    public $duracion;
    public $costo_total;

    public function __construct($id, $nombre, $email, $edad, $plan_base, $duracion, $costo_total) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->email = $email;
        $this->edad = $edad;
        $this->plan_base = $plan_base;
        $this->duracion = $duracion;
        $this->costo_total = $costo_total;
    }
}
?>



