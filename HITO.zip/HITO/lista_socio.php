<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Socios</title>
    <link rel="stylesheet" href="styles.css"> 
</head>
<body>

<h1>Lista de Socios</h1>

<table>
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Email</th>
        <th>Edad</th>
        <th>Plan Base</th>
        <th>Duración</th>
        <th>Costo Total</th>
        <th>Acciones</th>
    </tr>
    <?php
    require_once "socioscontroller.php";
    $socioController = new SociosController();
    $socios = $socioController->obtenerSocios();

    foreach ($socios as $socio): ?>
        <tr>
            <td><?php echo $socio->id; ?></td>
            <td><?php echo $socio->nombre; ?></td>
            <td><?php echo $socio->email; ?></td>
            <td><?php echo $socio->edad; ?></td>
            <td><?php echo $socio->plan_base; ?></td>
            <td><?php echo $socio->duracion; ?></td>
            <td><?php echo $socio->costo_total; ?> €</td>
            <td>
                <a href="editar_socio.php?id=<?php echo $socio->id; ?>" class="edit">Editar</a>
                <a href="eliminar_socio.php?id=<?php echo $socio->id; ?>" class="delete" onclick="return confirm('¿Estás seguro de eliminar este socio?')">Eliminar</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<a href="agregar_socio.php" class="add">Agregar nuevo socio</a>
</body>
</html>









