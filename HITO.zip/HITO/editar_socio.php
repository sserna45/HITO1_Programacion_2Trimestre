<?php
require_once "socioscontroller.php";

$controlador = new SociosController();
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$socio = $controlador->obtenerSocio($id);

if (!$socio) {
    die("Error: No se encontró el socio.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $edad = $_POST["edad"];
    $plan_base = $_POST["plan_base"];
    $duracion = $_POST["duracion"];

    $socioEditado = new Socio($id, $nombre, $email, $edad, $plan_base, $duracion, 10); 
    $controlador->editarSocio($socioEditado);

    header("Location: lista_socio.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Socio</title>
    <link rel="stylesheet" href="styles.css"> 
</head>
<body>

    <form method="post">
        <input type="hidden" name="id" value="<?php echo $socio->id; ?>">

        <label>Nombre:</label>
        <input type="text" name="nombre" value="<?php echo $socio->nombre; ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?php echo $socio->email; ?>" required>

        <label>Edad:</label>
        <input type="number" name="edad" value="<?php echo $socio->edad; ?>" required>

        <label>Plan Base:</label>
        <select name="plan_base">
            <option value="Básico" <?php if ($socio->plan_base == 'Básico') echo 'selected'; ?>>Básico</option>
            <option value="Estándar" <?php if ($socio->plan_base == 'Estándar') echo 'selected'; ?>>Estándar</option>
            <option value="Premium" <?php if ($socio->plan_base == 'Premium') echo 'selected'; ?>>Premium</option>
        </select>
        <label>Duración:</label>
        <select name="duracion">
            <option value="mensual" <?php if ($socio->duracion == 'mensual') echo 'selected'; ?>>Mensual</option>
            <option value="anual" <?php if ($socio->duracion == 'anual') echo 'selected'; ?>>Anual</option>
        </select>
        <input type="submit" value="Actualizar">
    </form>
    <a href="lista_socio.php">Volver a la lista</a>

</body>
</html>





