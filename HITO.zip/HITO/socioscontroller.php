<?php
require_once "conexion.php";
require_once "class_socio.php";

class SociosController {
    private $db;

    public function __construct() {
        $conexion = new Conexion();
        $this->db = $conexion->conectar();
    }

    public function obtenerSocios() {
        $stmt = $this->db->query("SELECT * FROM socios");
        $socios = [];

        while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $socios[] = new Socio(
                $fila["id"],
                $fila["nombre"],
                $fila["email"],
                $fila["edad"],
                $fila["plan_base"],
                $fila["duracion"],
                $fila["costo_total"]
            );
        }
        return $socios;
    }

    public function obtenerSocio($id) {
        $stmt = $this->db->prepare("SELECT * FROM socios WHERE id = ?");
        $stmt->execute([$id]);
        $socio = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($socio) {
            return new Socio(
                $socio["id"],
                $socio["nombre"],
                $socio["email"],
                $socio["edad"],
                $socio["plan_base"],
                $socio["duracion"],
                $socio["costo_total"]
            );
        }
        return null;
    }

    public function agregarSocio(Socio $socio) {
        $stmt = $this->db->prepare("INSERT INTO socios (nombre, email, edad, plan_base, duracion, costo_total) VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([
            $socio->nombre,
            $socio->email,
            $socio->edad,
            $socio->plan_base,
            $socio->duracion,
            $socio->costo_total
        ]);
    }

    public function editarSocio(Socio $socio) {
        $stmt = $this->db->prepare("UPDATE socios SET nombre = ?, email = ?, edad = ?, plan_base = ?, duracion = ?, costo_total = ? WHERE id = ?");
        return $stmt->execute([
            $socio->nombre,
            $socio->email,
            $socio->edad,
            $socio->plan_base,
            $socio->duracion,
            $socio->costo_total,
            $socio->id
        ]);
    }

    public function eliminarSocio($id) {
        $stmt = $this->db->prepare("DELETE FROM socios WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>



