CREATE DATABASE hito;
USE hito;

CREATE TABLE socios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    edad INT NOT NULL,
    plan_base ENUM('Básico', 'Estándar', 'Premium') NOT NULL,
    paquetes_adicionales TEXT,
    duracion ENUM('mensual', 'anual') NOT NULL,
    costo_total DECIMAL(10,2) NOT NULL
);

INSERT INTO socios (nombre, email, edad, plan_base, paquetes_adicionales, duracion, costo_total) VALUES
('Carlos Pérez', 'carlos@gmail.com', 28, 'Básico', 'Deportes, Documentales', 'mensual', 12.99),
('María López', 'maria@gmail.com', 35, 'Estándar', 'Cine, Infantil', 'anual', 99.99),
('José Martínez', 'jose@gmail.com', 40, 'Premium', 'Cine, Deportes, Series', 'mensual', 19.99),
('Ana García', 'ana@gmail.com', 22, 'Básico', 'Infantil', 'anual', 49.99),
('Luis Fernández', 'luis@gmail.com', 31, 'Estándar', 'Cine, Documentales', 'mensual', 15.99);
