<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>StreamWeb</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Bienvenido a StreamWeb</h1>
    <p>Bienvenido, aquí se gestionan las socios y las suscripciones.</p>

    <ul class="menu">
        <li><a href="lista_socio.php">Ver lista de socios</a></li>
        <li><a href="agregar_socio.php">Agregar nuevo socio</a></li>
    </ul>
</body>
</html>

