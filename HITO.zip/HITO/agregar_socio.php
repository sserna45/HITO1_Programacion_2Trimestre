<?php
require_once "socioscontroller.php";

$socioController = new SociosController();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $edad = $_POST["edad"];
    $plan_base = $_POST["plan_base"];
    $duracion = $_POST["duracion"];
    $costo_total = 10; 

    $nuevoSocio = new Socio(null, $nombre, $email, $edad, $plan_base, $duracion, $costo_total);
    $socioController->agregarSocio($nuevoSocio);

    header("Location: lista_socio.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Socio</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Agregar Nuevo Socio</h2>
        <form method="post">
            <label>Nombre:</label>
            <input type="text" name="nombre" required>

            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Edad:</label>
            <input type="number" name="edad" required>

            <label>Plan Base:</label>
            <select name="plan_base">
                <option value="Básico">Básico</option>
                <option value="Estándar">Estándar</option>
                <option value="Premium">Premium</option>
            </select>

            <label>Duración:</label>
            <select name="duracion">
                <option value="mensual">Mensual</option>
                <option value="anual">Anual</option>
            </select>

            <button type="submit">Agregar</button>
        </form>

        <a href="lista_socio.php" class="btn">Volver</a>
    </div>
</body>
</html>





